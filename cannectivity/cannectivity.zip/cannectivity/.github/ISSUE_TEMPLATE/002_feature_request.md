---
name: Feature request
about: Suggest a new feature for CANnectivity
title: ''
labels: enhancement
assignees: ''
---

## Describe the requested feature
<!-- A clear and concise description of the feature being requested. -->

## Describe alternatives considered
<!-- A clear and concise description of alternatives already considered. -->

## Additional context
<!--
Add any other context that could be relevant to your request.
-->
